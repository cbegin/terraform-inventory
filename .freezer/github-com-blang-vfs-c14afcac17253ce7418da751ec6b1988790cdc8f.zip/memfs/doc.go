// Package memfs defines an in-memory filesystem
package memfs
